
<div align="right">



            <button>   <a href="<?php echo site_url("Rbsctrl/logout") ?> ">
              <i class="zmdi zmdi-power"></i>Logout</a></button>


</div>
<h1 align="centers"> your on the queue for admin aproval</h1>
