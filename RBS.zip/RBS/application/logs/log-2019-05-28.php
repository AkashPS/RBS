<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-28 02:44:56 --> Severity: error --> Exception: syntax error, unexpected ',' C:\xampp\htdocs\RBS\application\controllers\Rbsctrl.php 180
ERROR - 2019-05-28 02:45:15 --> Severity: error --> Exception: syntax error, unexpected ',' C:\xampp\htdocs\RBS\application\controllers\Rbsctrl.php 180
ERROR - 2019-05-28 02:45:18 --> Severity: error --> Exception: syntax error, unexpected ',' C:\xampp\htdocs\RBS\application\controllers\Rbsctrl.php 180
ERROR - 2019-05-28 02:45:20 --> Severity: error --> Exception: syntax error, unexpected ',' C:\xampp\htdocs\RBS\application\controllers\Rbsctrl.php 180
ERROR - 2019-05-28 02:45:29 --> Severity: error --> Exception: syntax error, unexpected ',' C:\xampp\htdocs\RBS\application\controllers\Rbsctrl.php 180
ERROR - 2019-05-28 02:46:11 --> Severity: error --> Exception: syntax error, unexpected ',' C:\xampp\htdocs\RBS\application\controllers\Rbsctrl.php 180
ERROR - 2019-05-28 02:55:31 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\RBS\application\controllers\Rbsctrl.php 179
