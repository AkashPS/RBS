ERROR - 2019-05-24 05:58:00 --> 
ERROR - 2019-05-24 05:59:06 --> 
ERROR - 2019-05-24 06:02:09 --> 
ERROR - 2019-05-24 06:02:09 --> Unable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Fri, 24 May 2019 06:01:57 +0200
From: &quot;Roady - Travel Companion&quot; &lt;admin@roady.com&gt;
Return-Path: &lt;admin@roady.com&gt;
Reply-To: &lt;admin@roady.com&gt;
User-Agent: CodeIgniter
X-Sender: admin@roady.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5ce76cb55b65b@roady.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Approval=20Success?=
We are happy to inform you that you are now a member of Roady - Travel
Companion. You are approved and can provide service to your customers. You
will be directed to your profile and requested to enter valid data.
</pre>
ERROR - 2019-05-24 06:09:50 --> 
ERROR - 2019-05-24 06:09:50 --> Unable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Fri, 24 May 2019 06:09:38 +0200
From: &quot;Roady - Travel Companion&quot; &lt;admin@roady.com&gt;
Return-Path: &lt;admin@roady.com&gt;
Reply-To: &lt;admin@roady.com&gt;
User-Agent: CodeIgniter
X-Sender: admin@roady.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5ce76e82b5467@roady.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Approval=20Success?=
We are happy to inform you that you are now a member of Roady - Travel
Companion. You are approved and can provide service to your customers. You
will be directed to your profile and requested to enter valid data.
</pre>
ERROR - 2019-05-24 06:10:26 --> 
ERROR - 2019-05-24 06:10:26 --> Unable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Fri, 24 May 2019 06:10:14 +0200
From: &quot;Roady - Travel Companion&quot; &lt;admin@roady.com&gt;
Return-Path: &lt;admin@roady.com&gt;
Reply-To: &lt;admin@roady.com&gt;
User-Agent: CodeIgniter
X-Sender: admin@roady.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5ce76ea693b03@roady.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Approval=20Success?=
We are happy to inform you that you are now a member of Roady - Travel
Companion. You are approved and can provide service to your customers. You
will be directed to your profile and requested to enter valid data.
</pre>
ERROR - 2019-05-24 06:12:07 --> 
ERROR - 2019-05-24 06:12:07 --> Unable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Fri, 24 May 2019 06:12:03 +0200
From: &quot;Roady - Travel Companion&quot; &lt;admin@roady.com&gt;
Return-Path: &lt;admin@roady.com&gt;
Reply-To: &lt;admin@roady.com&gt;
User-Agent: CodeIgniter
X-Sender: admin@roady.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5ce76f13a62dc@roady.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Approval=20Success?=
We are happy to inform you that you are now a member of Roady - Travel
Companion. You are approved and can provide service to your customers. You
will be directed to your profile and requested to enter valid data.
</pre>
ERROR - 2019-05-24 06:14:14 --> 
ERROR - 2019-05-24 06:14:14 --> Unable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Fri, 24 May 2019 06:14:02 +0200
From: &quot;Roady - Travel Companion&quot; &lt;admin@roady.com&gt;
Return-Path: &lt;admin@roady.com&gt;
Reply-To: &lt;admin@roady.com&gt;
User-Agent: CodeIgniter
X-Sender: admin@roady.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5ce76f8a6f180@roady.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Approval=20Success?=
We are happy to inform you that you are now a member of Roady - Travel
Companion. You are approved and can provide service to your customers. You
will be directed to your profile and requested to enter valid data.
</pre>
ERROR - 2019-05-24 06:18:19 --> 
ERROR - 2019-05-24 06:18:19 --> Unable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Fri, 24 May 2019 06:18:07 +0200
From: &quot;Roady - Travel Companion&quot; &lt;admin@roady.com&gt;
Return-Path: &lt;admin@roady.com&gt;
Reply-To: &lt;admin@roady.com&gt;
User-Agent: CodeIgniter
X-Sender: admin@roady.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5ce7707f770ce@roady.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Approval=20Success?=
We are happy to inform you that you are now a member of Roady - Travel
Companion. You are approved and can provide service to your customers. You
will be directed to your profile and requested to enter valid data.
</pre>
ERROR - 2019-05-24 11:46:41 --> 
ERROR - 2019-05-24 11:46:42 --> Unable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Fri, 24 May 2019 11:46:34 +0200
From: &quot;Roady - Travel Companion&quot; &lt;admin@roady.com&gt;
Return-Path: &lt;admin@roady.com&gt;
Reply-To: &lt;admin@roady.com&gt;
User-Agent: CodeIgniter
X-Sender: admin@roady.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5ce7bd7a96ded@roady.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Approval=20Success?=
We are happy to inform you that you are now a member of Roady - Travel
Companion. You are approved and can provide service to your customers. You
will be directed to your profile and requested to enter valid data.
</pre>
ERROR - 2019-05-24 11:47:38 --> 
ERROR - 2019-05-24 11:47:38 --> Unable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Fri, 24 May 2019 11:47:24 +0200
From: &quot;Roady - Travel Companion&quot; &lt;admin@roady.com&gt;
Return-Path: &lt;admin@roady.com&gt;
Reply-To: &lt;admin@roady.com&gt;
User-Agent: CodeIgniter
X-Sender: admin@roady.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5ce7bdace7170@roady.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Approval=20Success?=
We are happy to inform you that you are now a member of Roady - Travel
Companion. You are approved and can provide service to your customers. You
will be directed to your profile and requested to enter valid data.
</pre>
ERROR - 2019-05-24 11:51:41 --> 
ERROR - 2019-05-24 11:51:41 --> Unable to send email using PHP mail(). Your server might not be configured to send mail using this method.<br /><pre>Date: Fri, 24 May 2019 11:51:40 +0200
From: &quot;Roady - Travel Companion&quot; &lt;admin@roady.com&gt;
Return-Path: &lt;admin@roady.com&gt;
Reply-To: &lt;admin@roady.com&gt;
User-Agent: CodeIgniter
X-Sender: admin@roady.com
X-Mailer: CodeIgniter
X-Priority: 3 (Normal)
Message-ID: &lt;5ce7beac4ff13@roady.com&gt;
Mime-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
=?UTF-8?Q?Approval=20Success?=
We are happy to inform you that you are now a member of Roady - Travel
Companion. You are approved and can provide service to your customers. You
will be directed to your profile and requested to enter valid data.
</pre>
